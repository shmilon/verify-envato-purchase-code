<?php
    $client_lang = array();
    
    $client_lang['1'] = "Please enter user name...";
    
    $client_lang['2'] ="Please enter password...";
    
    $client_lang['3'] ="Response message has been sent..";
    
    $client_lang['4'] ="Please enter correct user name or passwrod..";
    
    $client_lang['5'] ="Response message not sent..";
    
    $client_lang['6'] ="Password has been sent to in your email address..";
    
    $client_lang['7'] ="Email not sent..please try again";
    
    $client_lang['8'] ="Email address is not available in our database..";
    
    $client_lang['9'] = "Please enter email address..";

    $client_lang['10'] = "Added successfully...";
    
    $client_lang['11'] = "Updated successfully...";
    
    $client_lang['12'] = "Delete successfully...";
    
    $client_lang['13'] = "Enable successfully...";
    
    $client_lang['14'] = "Disable successfully...";
    
    $client_lang['15'] = "Please select wallpaper image...";
    
    $client_lang['16'] = "successfully...";
    
    $client_lang['18'] = "Envato purchase code is wrong!"; 
    
    $client_lang['19'] = "Verified successfully!"; 
    
    
    $client_lang['20']="Password has been sent on your mail.";
    
    $client_lang['21']="Email is not found !";

	  
	  
	   
	  
?>
